# JARVIS AI - Ekam Edition (Android, Kotlin)

Package: com.ekam.jarvis | minSdk 26 | targetSdk/compileSdk 34 | AGP 8.5.2 | Kotlin 1.9.24 | Gradle 8.7 | JDK 17

## Build
1. Install Android Studio (Koala or newer). Open the `JarvisAI` folder.
2. Let Gradle sync (needs internet once to download dependencies). If asked for the Gradle wrapper, accept, or run `gradle wrapper --gradle-version 8.7`.
3. Connect a phone (USB debugging) or start an emulator and press Run.
4. APK: Build > Build APK(s).

## Dependencies
androidx core-ktx 1.13.1, appcompat 1.7.0, biometric 1.1.0, security-crypto 1.1.0-alpha06, CameraX 1.3.4 (core, camera2, lifecycle).

## Supported commands
- Greetings: hello, good morning, good night, welcome back, how are you, namaste, sat sri akal, kaise ho
- Apps: open youtube / gmail / whatsapp / chrome / maps / play store; open <any installed app or game name>
- YouTube: search youtube for <x>; play <x>; guide for <game>
- Settings: wifi, bluetooth, hotspot, location, open settings
- Flashlight on / off (also torch, "band" for off)
- battery, time, set timer 10 minutes
- note <text> (saved encrypted), show notes; tips; go to sleep
- Wake phrase "Hey Spidey" is stripped if you say it before a command (see limitations).

## Works offline
Avatar, typed commands, app/settings launching, flashlight, battery, time, notes, PIN, biometrics, security photo, timer.
Needs internet: speech recognition for most devices/languages (Google speech service), YouTube search results.

## Privacy
- Mic: only after you tap the mic button, after a permission explanation.
- Camera: only if you switch on Security photo in the private area (explanation dialog first). Photos stay in app-private storage, max 10, never uploaded, deletable.
- PIN: salted PBKDF2 hash inside EncryptedSharedPreferences (Keystore). Cooldown from the 3rd wrong attempt: 30s, doubling up to 15 min.
- Private screen blocks screenshots (FLAG_SECURE).
- No contacts, location, or calendar access is requested.

## Known limitations (honest list)
- This project was written without a build environment: it has NOT been compiled or run on a device. Expect to fix small compile errors on first sync. Test every command on your phone.
- JARVIS is rule-based, not an LLM. Unknown sentences get a "don't know" reply.
- No always-on wake word: that needs a dedicated engine (e.g. Porcupine) and drains battery. "Hey Spidey" only works when said inside a mic command.
- Hindi / Punjabi depend on the phone's speech service; untested.
- Weather, calendar, reminders, and contacts are NOT implemented (they would need extra permissions and an API key).
- Hotspot shortcut is device-specific; fallback opens network settings.
- Security photo works only while the app is open in the foreground, and only for PIN attempts in this app. It cannot touch the system lock screen. Some phones give a dark photo without camera preview.
- Games with anti-cheat are only launched, never touched.
- Launcher icon is a simple vector placeholder; replace it with your own artwork.
