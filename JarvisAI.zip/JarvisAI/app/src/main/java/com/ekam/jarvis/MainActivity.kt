package com.ekam.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), VoiceManager.Callback {

    private lateinit var avatar: AvatarView
    private lateinit var tvStatus: TextView
    private lateinit var tvReply: TextView
    private lateinit var tvTime: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvBattery: TextView
    private lateinit var input: EditText
    private lateinit var commands: CommandHandler
    private lateinit var voice: VoiceManager

    private val ui = Handler(Looper.getMainLooper())
    private var sleeping = false
    private val langs = listOf("en-IN" to "EN", "hi-IN" to "HI", "pa-IN" to "PA")
    private var langIdx = 0
    private val wakePhrase = "hey spidey"

    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startListening()
        else show("Microphone permission denied. You can still type commands.", AvatarView.State.IDLE)
    }

    private val tick = object : Runnable {
        override fun run() { updateDashboard(); ui.postDelayed(this, 30_000) }
    }
    private val sleepTimer = Runnable { goToSleep() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        avatar = findViewById(R.id.avatar)
        tvStatus = findViewById(R.id.tvStatus)
        tvReply = findViewById(R.id.tvReply)
        tvTime = findViewById(R.id.tvTime)
        tvDate = findViewById(R.id.tvDate)
        tvBattery = findViewById(R.id.tvBattery)
        input = findViewById(R.id.etInput)

        commands = CommandHandler(this, SecureStore(this))
        voice = VoiceManager(this, this)

        findViewById<Button>(R.id.btnMic).setOnClickListener { micClicked() }
        findViewById<Button>(R.id.btnSend).setOnClickListener { sendTyped() }
        input.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { sendTyped(); true } else false }
        findViewById<Button>(R.id.btnPrivate).setOnClickListener { startActivity(Intent(this, PinActivity::class.java)) }
        val btnLang = findViewById<Button>(R.id.btnLang)
        btnLang.setOnClickListener {
            langIdx = (langIdx + 1) % langs.size
            voice.languageTag = langs[langIdx].first
            btnLang.text = langs[langIdx].second
            show("Language set to ${langs[langIdx].second}. Hindi and Punjabi depend on your phone's speech service.", AvatarView.State.IDLE)
        }
        buildQuickActions()

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        avatar.nightMode = hour >= 22 || hour < 5
        avatar.state = AvatarView.State.WAKEUP
        show("Hello, ${Config.OWNER}! Your friendly AI assistant is online.", AvatarView.State.HAPPY)
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
        resetSleepTimer()
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        ui.removeCallbacks(sleepTimer)
        voice.stop()
        super.onPause()
    }

    override fun onDestroy() {
        voice.shutdown()
        super.onDestroy()
    }

    override fun onUserInteraction() {
        if (sleeping) wakeUp()
        resetSleepTimer()
    }

    // ---------- sleep / wake ----------
    private fun resetSleepTimer() { ui.removeCallbacks(sleepTimer); ui.postDelayed(sleepTimer, 60_000) }

    private fun goToSleep() {
        sleeping = true
        avatar.state = AvatarView.State.SLEEP
        tvStatus.text = "SLEEPING"
    }

    private fun wakeUp() {
        sleeping = false
        avatar.state = AvatarView.State.WAKEUP
        show("Welcome back, ${Config.OWNER}!", AvatarView.State.HAPPY)
        ui.postDelayed({ if (avatar.state == AvatarView.State.WAKEUP) avatar.state = AvatarView.State.IDLE }, 2500)
    }

    // ---------- input ----------
    private fun micClicked() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Microphone access")
                .setMessage("JARVIS uses the microphone only while you tap the mic button, to turn your speech into a command.")
                .setPositiveButton("Allow") { _, _ -> micPerm.launch(Manifest.permission.RECORD_AUDIO) }
                .setNegativeButton("Not now", null).show()
        }
    }

    private fun startListening() { voice.listen() }

    private fun sendTyped() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.text.clear()
        process(text)
    }

    private fun process(raw: String) {
        val text = raw.lowercase(Locale.ROOT).removePrefix(wakePhrase).trim(' ', ',', '.')
        avatar.state = AvatarView.State.THINKING
        tvStatus.text = "THINKING"
        ui.postDelayed({
            val r = commands.handle(text)
            show(r.reply, if (r.happy) AvatarView.State.HAPPY else AvatarView.State.IDLE)
            if (r.sleep) ui.postDelayed({ goToSleep() }, 3500)
        }, 450)
    }

    private fun show(text: String, state: AvatarView.State) {
        tvReply.text = text
        avatar.state = state
        tvStatus.text = state.name
        voice.speak(text)
    }

    private fun buildQuickActions() {
        val row = findViewById<LinearLayout>(R.id.quickRow)
        val items = listOf("YouTube" to "open youtube", "Gmail" to "open gmail", "WhatsApp" to "open whatsapp",
            "Chrome" to "open chrome", "Maps" to "open maps", "Play Store" to "open play store",
            "Wi-Fi" to "wifi", "Bluetooth" to "bluetooth", "Hotspot" to "hotspot", "Location" to "location",
            "Torch on" to "flashlight on", "Torch off" to "flashlight off", "Settings" to "open settings",
            "Battery" to "battery", "Time" to "time")
        for ((label, cmd) in items) {
            val b = Button(this, null, 0, R.style.NeonButton)
            b.text = label
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = 8
            b.layoutParams = lp
            b.setOnClickListener { process(cmd) }
            row.addView(b)
        }
    }

    private fun updateDashboard() {
        val now = Date()
        tvTime.text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(now)
        tvDate.text = SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(now)
        tvBattery.text = "BAT ${commands.batteryPercent()}%"
    }

    // ---------- VoiceManager.Callback ----------
    override fun onListening() { avatar.state = AvatarView.State.LISTENING; tvStatus.text = "LISTENING" }
    override fun onResult(text: String) { tvReply.text = "\"$text\""; process(text) }
    override fun onError(message: String) { show(message, AvatarView.State.IDLE) }
    override fun onSpeakStart() { if (!sleeping) { avatar.state = AvatarView.State.SPEAKING; tvStatus.text = "SPEAKING" } }
    override fun onSpeakDone() {
        if (!sleeping && avatar.state == AvatarView.State.SPEAKING) { avatar.state = AvatarView.State.IDLE; tvStatus.text = "ONLINE" }
    }
}
