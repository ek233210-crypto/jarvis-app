package com.ekam.jarvis

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Config { const val OWNER = "Ekam" }

/** Rule-based command parser. It is NOT an LLM: it only understands the commands listed in README. */
class CommandHandler(private val ctx: Context, private val store: SecureStore) {

    data class Result(val reply: String, val happy: Boolean = false, val sleep: Boolean = false)

    private val apps = linkedMapOf(
        "play store" to ("Play Store" to "com.android.vending"),
        "youtube" to ("YouTube" to "com.google.android.youtube"),
        "gmail" to ("Gmail" to "com.google.android.gm"),
        "whatsapp" to ("WhatsApp" to "com.whatsapp"),
        "chrome" to ("Chrome" to "com.android.chrome"),
        "maps" to ("Google Maps" to "com.google.android.apps.maps")
    )
    private val tips = listOf(
        "Tip: warm up in practice mode before ranked matches.",
        "Tip: use headphones, sound cues often reveal enemy positions.",
        "Tip: take a short break every hour, your reaction time improves.",
        "Tip: review your last match and note one mistake to fix."
    )
    private var tipIdx = 0

    fun batteryPercent(): Int =
        (ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

    fun handle(raw: String): Result {
        val t = raw.lowercase(Locale.ROOT).trim()
        fun has(re: String) = Regex(re).containsMatchIn(t)
        return when {
            t.isEmpty() -> Result("Say or type a command.")
            "good night" in t -> Result("Good night, ${Config.OWNER}! Sleep well. Sweet dreams!", true, true)
            "go to sleep" in t || "sleep mode" in t -> Result("Going to sleep. Tap the screen to wake me.", false, true)
            "good morning" in t -> Result("Good morning, ${Config.OWNER}! Ready to make today awesome?", true)
            "welcome back" in t -> Result("Thanks, ${Config.OWNER}! Good to see you again.", true)
            "how are you" in t || "kaise ho" in t -> Result("I'm running at full power, ${Config.OWNER}! How are you?", true)
            has("^(hello|hi|hey|namaste|sat sri akal)\\b") ->
                Result("Hello, ${Config.OWNER}! Your friendly AI assistant is online.", true)

            has("\\btimer\\b") -> timer(t)
            has("\\b(time|samay)\\b") ->
                Result("It's ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())}.")
            "battery" in t -> Result("Battery is at ${batteryPercent()} percent.")
            "flashlight" in t || "torch" in t -> torch(!has("\\b(off|band)\\b"))

            t.startsWith("note ") -> {
                store.addNote(t.removePrefix("note ").trim()); Result("Saved your note privately.", true)
            }
            "show notes" in t || "my notes" in t -> {
                val n = store.notes
                Result(if (n.isBlank()) "You have no notes yet." else "Your notes:\n$n")
            }

            "youtube" in t && ("search" in t || t.startsWith("play ")) || t.startsWith("play ") ->
                youtubeSearch(youtubeQuery(t))
            "guide for " in t -> youtubeSearch(t.substringAfter("guide for ").trim() + " guide")
            has("\\b(tip|tips)\\b") -> Result(tips[tipIdx++ % tips.size])

            "wifi" in t || "wi-fi" in t -> settings(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi settings")
            "bluetooth" in t -> settings(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings")
            "hotspot" in t -> hotspot()
            "location" in t -> settings(Settings.ACTION_LOCATION_SOURCE_SETTINGS, "location settings")
            t.startsWith("open settings") || t == "settings" -> settings(Settings.ACTION_SETTINGS, "Settings")

            t.startsWith("open ") || t.startsWith("launch ") || t.startsWith("start ") -> openByName(t)
            else -> Result("Sorry, I don't know that command yet. Try \"open YouTube\", \"flashlight on\" or \"battery\".")
        }
    }

    // ---------- helpers ----------

    private fun start(i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: ActivityNotFoundException) { false } catch (e: SecurityException) { false }

    private fun settings(action: String, label: String): Result =
        if (start(Intent(action))) Result("Opening $label.", true)
        else Result("I couldn't open $label on this phone.")

    private fun hotspot(): Result {
        val direct = Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings")
        return when {
            start(direct) -> Result("Opening hotspot settings.", true)
            start(Intent(Settings.ACTION_WIRELESS_SETTINGS)) ->
                Result("This phone doesn't allow a direct shortcut, so I opened network settings. Hotspot is in there.")
            else -> Result("I couldn't open hotspot settings.")
        }
    }

    private fun launchPackage(pkg: String, label: String): Result {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
        return if (i != null && start(i)) Result("Opening $label.", true)
        else Result("$label is not installed on this phone.")
    }

    private fun openByName(t: String): Result {
        val name = t.substringAfter(" ").removePrefix("the ").removePrefix("game ").removeSuffix(" app").trim()
        for ((key, v) in apps) if (key in name) return launchPackage(v.second, v.first)
        if (name.isEmpty()) return Result("Which app should I open?")
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(name)
        } ?: return Result("I couldn't find an installed app named $name.")
        return launchPackage(match.activityInfo.packageName, match.loadLabel(pm).toString())
    }

    private fun youtubeQuery(t: String): String {
        val q = when {
            "youtube search for " in t -> t.substringAfter("youtube search for ")
            "search youtube for " in t -> t.substringAfter("search youtube for ")
            "search for " in t -> t.substringAfter("search for ")
            t.startsWith("play ") -> t.removePrefix("play ")
            else -> t.substringAfter("search ")
        }
        return q.replace("on youtube", "").replace("youtube", "").trim()
    }

    private fun youtubeSearch(q: String): Result {
        if (q.isEmpty()) return Result("What should I search for on YouTube?")
        val app = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        if (start(app)) return Result("Searching YouTube for $q.", true)
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
        return if (start(web)) Result("The YouTube app wasn't available, so I opened the search in your browser.")
        else Result("I couldn't open YouTube search.")
    }

    private fun timer(t: String): Result {
        val m = Regex("(\\d+)\\s*(hour|hr|minute|min|second|sec)").find(t)
            ?: return Result("Say for example: set timer 10 minutes.")
        val n = m.groupValues[1].toInt()
        val secs = when (m.groupValues[2]) { "hour", "hr" -> n * 3600; "minute", "min" -> n * 60; else -> n }
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS timer")
        return if (start(i)) Result("Setting a timer for ${m.value}.", true)
        else Result("No clock app on this phone can take a timer from me.")
    }

    private fun torch(on: Boolean): Result {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        return try {
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return Result("This phone has no flashlight I can control.")
            cm.setTorchMode(id, on)
            Result(if (on) "Flashlight on." else "Flashlight off.", true)
        } catch (e: Exception) {
            Result("I couldn't change the flashlight: ${e.message}")
        }
    }
}
