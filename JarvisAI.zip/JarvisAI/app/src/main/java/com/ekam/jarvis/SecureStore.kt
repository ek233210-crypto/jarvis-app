package com.ekam.jarvis

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.min

/** Encrypted storage (Android Keystore backed). The PIN is stored only as a salted PBKDF2 hash. */
class SecureStore(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context, "jarvis_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)).encoded

    fun hasPin() = prefs.contains("pin_hash")

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit().putString("pin_salt", b64(salt)).putString("pin_hash", b64(hash(pin, salt))).apply()
        resetFails()
    }

    fun clearPin() {
        prefs.edit().remove("pin_hash").remove("pin_salt").apply()
        resetFails()
    }

    fun verifyPin(pin: String): Boolean {
        val s = prefs.getString("pin_salt", null) ?: return false
        val h = prefs.getString("pin_hash", null) ?: return false
        return MessageDigest.isEqual(hash(pin, Base64.decode(s, Base64.NO_WRAP)), Base64.decode(h, Base64.NO_WRAP))
    }

    /** Returns the number of consecutive failures. From the 3rd failure a growing cooldown starts (30s .. 15min). */
    fun recordFail(): Int {
        val n = prefs.getInt("fails", 0) + 1
        val lock = if (n >= 3) min(15 * 60_000L, 30_000L shl (n - 3).coerceAtMost(5)) else 0L
        prefs.edit().putInt("fails", n).putLong("lock_until", if (lock > 0) System.currentTimeMillis() + lock else 0L).apply()
        return n
    }

    fun resetFails() { prefs.edit().putInt("fails", 0).putLong("lock_until", 0L).apply() }

    fun lockRemainingMs(): Long = (prefs.getLong("lock_until", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    var photoEnabled: Boolean
        get() = prefs.getBoolean("photo_enabled", false)
        set(v) { prefs.edit().putBoolean("photo_enabled", v).apply() }

    var notes: String
        get() = prefs.getString("notes", "") ?: ""
        set(v) { prefs.edit().putString("notes", v).apply() }

    fun addNote(text: String) {
        val stamp = java.text.SimpleDateFormat("dd MMM HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        notes = (notes + "\n[$stamp] $text").trim()
    }
}
