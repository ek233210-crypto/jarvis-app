package com.ekam.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Wraps Android SpeechRecognizer (speech-to-text) and TextToSpeech. */
class VoiceManager(private val ctx: Context, private val cb: Callback) : TextToSpeech.OnInitListener {

    interface Callback {
        fun onListening()
        fun onResult(text: String)
        fun onError(message: String)
        fun onSpeakStart()
        fun onSpeakDone()
    }

    var languageTag = "en-IN"
        set(v) { field = v; applyTtsLanguage() }

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = TextToSpeech(ctx, this)
    private var ttsReady = false
    private var pending: String? = null
    private var recognizer: SpeechRecognizer? = null

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (!ttsReady) return
        applyTtsLanguage()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { main.post { cb.onSpeakStart() } }
            override fun onDone(id: String?) { main.post { cb.onSpeakDone() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { cb.onSpeakDone() } }
        })
        pending?.let { speak(it) }
        pending = null
    }

    private fun applyTtsLanguage() {
        val t = tts ?: return
        if (!ttsReady) return
        val res = t.setLanguage(Locale.forLanguageTag(languageTag))
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.US)
    }

    fun speak(text: String) {
        if (tts == null) { cb.onSpeakDone(); return }
        if (!ttsReady) { pending = text; return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            cb.onError("Speech recognition is not available on this device. Please type your command.")
            return
        }
        tts?.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { cb.onListening() }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(code: Int) {
                    cb.onError(when (code) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Tap the mic and try again, or type it."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service needs internet for this language. You can type instead."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
                        else -> "Speech recognition failed (code $code). Please type your command."
                    })
                }
                override fun onResults(r: Bundle?) {
                    val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text.isNullOrBlank()) cb.onError("I didn't catch that. Please try again.") else cb.onResult(text)
                }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        recognizer?.startListening(i)
    }

    fun stop() { recognizer?.cancel(); tts?.stop() }

    fun shutdown() {
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
    }
}
