package com.ekam.jarvis

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class PinActivity : AppCompatActivity() {

    private lateinit var store: SecureStore
    private lateinit var lockPanel: View
    private lateinit var privatePanel: View
    private lateinit var title: TextView
    private lateinit var status: TextView
    private lateinit var etPin: EditText
    private lateinit var btnBio: Button
    private lateinit var tvNotes: TextView
    private lateinit var tvPhotos: TextView
    private lateinit var swPhoto: SwitchCompat

    private var creating = false
    private var pendingPin: String? = null
    private var ignoreSwitch = false

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) store.photoEnabled = true
        else {
            store.photoEnabled = false; setSwitch(false)
            Toast.makeText(this, "Camera permission denied. Security photo stays off.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_pin)
        store = SecureStore(this)
        lockPanel = findViewById(R.id.lockPanel)
        privatePanel = findViewById(R.id.privatePanel)
        title = findViewById(R.id.tvPinTitle)
        status = findViewById(R.id.tvPinStatus)
        etPin = findViewById(R.id.etPin)
        btnBio = findViewById(R.id.btnBio)
        tvNotes = findViewById(R.id.tvNotes)
        tvPhotos = findViewById(R.id.tvPhotos)
        swPhoto = findViewById(R.id.swPhoto)

        findViewById<Button>(R.id.btnUnlock).setOnClickListener { onOk() }
        btnBio.setOnClickListener { biometric() }
        findViewById<Button>(R.id.btnLock).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnClearNotes).setOnClickListener { store.notes = ""; refreshPrivate() }
        findViewById<Button>(R.id.btnDeletePhotos).setOnClickListener { SecurityCamera.deleteAll(this); refreshPrivate() }
        findViewById<Button>(R.id.btnChangePin).setOnClickListener {
            store.clearPin(); creating = true; pendingPin = null; showLock()
        }
        swPhoto.setOnCheckedChangeListener { _, checked -> if (!ignoreSwitch) onPhotoSwitch(checked) }

        creating = !store.hasPin()
        showLock()
    }

    private fun showLock() {
        privatePanel.visibility = View.GONE
        lockPanel.visibility = View.VISIBLE
        status.text = ""
        title.text = if (creating) "Create a PIN (4 to 8 digits)" else "Enter PIN"
        btnBio.visibility = if (!creating && canBiometric()) View.VISIBLE else View.GONE
    }

    private fun showPrivate() {
        lockPanel.visibility = View.GONE
        privatePanel.visibility = View.VISIBLE
        refreshPrivate()
    }

    private fun refreshPrivate() {
        tvNotes.text = store.notes.ifBlank { "No notes yet. Say or type: note buy milk" }
        tvPhotos.text = "Stored security photos: ${SecurityCamera.count(this)}"
        setSwitch(store.photoEnabled)
    }

    private fun setSwitch(v: Boolean) { ignoreSwitch = true; swPhoto.isChecked = v; ignoreSwitch = false }

    private fun onOk() {
        val pin = etPin.text.toString()
        etPin.text.clear()
        if (creating) {
            if (pin.length !in 4..8) { status.text = "PIN must be 4 to 8 digits."; return }
            val first = pendingPin
            when {
                first == null -> { pendingPin = pin; title.text = "Confirm PIN"; status.text = "" }
                first == pin -> { store.setPin(pin); creating = false; pendingPin = null; showPrivate() }
                else -> { pendingPin = null; title.text = "Create a PIN (4 to 8 digits)"; status.text = "PINs did not match. Try again." }
            }
            return
        }
        val wait = store.lockRemainingMs()
        if (wait > 0) { status.text = "Too many attempts. Try again in ${wait / 1000 + 1}s."; return }
        if (store.verifyPin(pin)) {
            store.resetFails(); showPrivate()
        } else {
            val n = store.recordFail()
            status.text = "Wrong PIN (attempt $n)."
            if (n >= 3 && store.photoEnabled) {
                SecurityCamera.capture(this)
                status.text = status.text.toString() + " A security photo was saved privately on this phone."
            }
        }
    }

    private fun onPhotoSwitch(checked: Boolean) {
        if (!checked) { store.photoEnabled = false; return }
        AlertDialog.Builder(this)
            .setTitle("Security photo")
            .setMessage("After 3 or more wrong PIN attempts inside this app, JARVIS will take a photo with the front camera while this screen is open. " +
                "Photos stay only in the app's private storage, are never uploaded, and you can delete them here at any time. " +
                "This does NOT cover your phone's lock screen. Use it only where the law allows.")
            .setPositiveButton("Enable") { _, _ ->
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                    store.photoEnabled = true
                else camPerm.launch(Manifest.permission.CAMERA)
            }
            .setNegativeButton("Cancel") { _, _ -> setSwitch(false) }
            .setOnCancelListener { setSwitch(false) }
            .show()
    }

    private fun canBiometric() = BiometricManager.from(this)
        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

    private fun biometric() {
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock JARVIS private area")
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                store.resetFails(); showPrivate()
            }
        }).authenticate(info)
    }
}
