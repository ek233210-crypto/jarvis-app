package com.ekam.jarvis

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import java.io.File

/** Opt-in security photo. Saved only in the app's private storage; never uploaded. */
object SecurityCamera {
    private const val MAX_PHOTOS = 10

    private fun dir(ctx: Context) = File(ctx.filesDir, "security").apply { mkdirs() }

    fun count(ctx: Context): Int = dir(ctx).listFiles()?.size ?: 0

    fun deleteAll(ctx: Context) { dir(ctx).listFiles()?.forEach { it.delete() } }

    fun capture(activity: AppCompatActivity) {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        val dir = dir(activity)
        val future = ProcessCameraProvider.getInstance(activity)
        future.addListener({
            try {
                val provider = future.get()
                val capture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                provider.unbindAll()
                provider.bindToLifecycle(activity, CameraSelector.DEFAULT_FRONT_CAMERA, capture)
                val file = File(dir, "attempt_${System.currentTimeMillis()}.jpg")
                capture.takePicture(
                    ImageCapture.OutputFileOptions.Builder(file).build(),
                    ContextCompat.getMainExecutor(activity),
                    object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                            provider.unbindAll(); prune(dir)
                        }
                        override fun onError(e: ImageCaptureException) { provider.unbindAll() }
                    })
            } catch (e: Exception) {
                // No front camera, or camera busy: skip silently.
            }
        }, ContextCompat.getMainExecutor(activity))
    }

    private fun prune(dir: File) {
        dir.listFiles()?.sortedBy { it.lastModified() }?.dropLast(MAX_PHOTOS)?.forEach { it.delete() }
    }
}
