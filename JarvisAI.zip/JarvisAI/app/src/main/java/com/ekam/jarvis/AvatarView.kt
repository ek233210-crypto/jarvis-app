package com.ekam.jarvis

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Round Spider-inspired avatar drawn on a Canvas (no extra libraries). */
class AvatarView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    View(context, attrs) {

    enum class State { IDLE, LISTENING, THINKING, SPEAKING, HAPPY, SLEEP, WAKEUP }

    var state: State = State.IDLE
        set(value) { field = value; invalidate() }
    var nightMode = false

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val red = Color.parseColor("#FF1744")
    private val oval = RectF()
    private var face: Shader? = null
    private var glow: Shader? = null
    private val tick = Runnable { invalidate() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = min(w, h) * 0.36f
        val cx = w / 2f
        val cy = h / 2f
        face = RadialGradient(cx, cy - r * 0.3f, r * 1.4f,
            intArrayOf(Color.parseColor("#3A0A12"), Color.parseColor("#12040A"), Color.BLACK),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        glow = RadialGradient(cx, cy, r * 1.45f,
            intArrayOf(Color.TRANSPARENT, Color.argb(160, 255, 23, 68), Color.TRANSPARENT),
            floatArrayOf(0.6f, 0.78f, 1f), Shader.TileMode.CLAMP)
    }

    private fun blink(t: Long): Float {
        val ph = t % 4200
        return if (ph < 180) 1f - sin(ph / 180.0 * PI).toFloat() * 0.95f else 1f
    }

    override fun onDraw(c: Canvas) {
        val t = SystemClock.uptimeMillis()
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2
        val r = min(w, h) * 0.36f
        val asleep = state == State.SLEEP
        val dim = if (asleep) 0.25f else if (nightMode) 0.6f else 1f
        fun col(color: Int, a: Float = 1f) { p.color = color; p.alpha = (255 * a * dim).toInt().coerceIn(0, 255) }

        // Glow
        val pulse = if (state == State.LISTENING) 0.75f + 0.25f * sin(t / 150.0).toFloat() else 0.85f
        p.style = Paint.Style.FILL; p.shader = glow; p.alpha = (255 * dim * pulse).toInt()
        c.drawCircle(cx, cy, r * 1.45f, p)
        p.shader = null

        // HUD rings
        if (!asleep) {
            p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.03f
            col(red, 0.9f)
            oval.set(cx - r * 1.12f, cy - r * 1.12f, cx + r * 1.12f, cy + r * 1.12f)
            c.drawArc(oval, (t / 18f) % 360, 80f, false, p)
            col(red, 0.5f)
            oval.set(cx - r * 1.24f, cy - r * 1.24f, cx + r * 1.24f, cy + r * 1.24f)
            c.drawArc(oval, 360 - (t / 25f) % 360, 50f, false, p)
        }

        // Face
        val bob = if (asleep) 0f else sin(t / 600.0).toFloat() * r * 0.03f
        c.save()
        c.translate(0f, bob)
        if (state == State.WAKEUP) c.scale(1f, 1f + 0.06f * sin(t / 200.0).toFloat(), cx, cy)
        p.style = Paint.Style.FILL; p.shader = face; p.alpha = 255
        c.drawCircle(cx, cy, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.04f; col(red)
        c.drawCircle(cx, cy, r, p)

        // Web lines on forehead
        p.strokeWidth = r * 0.012f; col(red, 0.45f)
        for (a in listOf(-0.6f, 0f, 0.6f)) {
            c.drawLine(cx, cy - r * 0.98f, cx + sin(a) * r * 0.45f, cy - r * 0.98f + cos(a) * r * 0.45f, p)
        }

        // Eyes
        val open = when {
            asleep -> 0.04f
            state == State.HAPPY -> 0.75f
            else -> blink(t)
        }
        val look = if (state == State.IDLE) sin(t / 1700.0).toFloat() * r * 0.05f else 0f
        p.style = Paint.Style.FILL
        for (s in listOf(-1, 1)) {
            val ex = cx + s * r * 0.38f
            val ey = cy - r * 0.1f
            oval.set(ex - r * 0.2f, ey - r * 0.26f * open, ex + r * 0.2f, ey + r * 0.26f * open)
            col(Color.WHITE); c.drawOval(oval, p)
            if (open > 0.3f) {
                col(red); c.drawCircle(ex + look, ey, r * 0.1f, p)
                col(Color.BLACK); c.drawCircle(ex + look, ey, r * 0.05f, p)
            }
        }

        // Cheeks when happy
        if (state == State.HAPPY) {
            col(Color.parseColor("#FF8A80"), 0.5f)
            c.drawCircle(cx - r * 0.62f, cy + r * 0.25f, r * 0.08f, p)
            c.drawCircle(cx + r * 0.62f, cy + r * 0.25f, r * 0.08f, p)
        }

        // Mouth
        val my = cy + r * 0.38f
        when (state) {
            State.SPEAKING -> {
                val o = abs(sin(t / 110.0)).toFloat()
                oval.set(cx - r * 0.14f, my - r * 0.02f, cx + r * 0.14f, my + r * (0.03f + 0.14f * o))
                col(red); p.style = Paint.Style.FILL; c.drawOval(oval, p)
            }
            State.HAPPY -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.05f; col(red)
                oval.set(cx - r * 0.28f, my - r * 0.2f, cx + r * 0.28f, my + r * 0.12f)
                c.drawArc(oval, 20f, 140f, false, p)
            }
            State.LISTENING -> { p.style = Paint.Style.FILL; col(red); c.drawCircle(cx, my, r * 0.06f, p) }
            State.THINKING, State.SLEEP -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.04f; col(red)
                c.drawLine(cx - r * 0.1f, my, cx + r * 0.1f, my, p)
            }
            else -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.04f; col(red)
                oval.set(cx - r * 0.18f, my - r * 0.1f, cx + r * 0.18f, my + r * 0.08f)
                c.drawArc(oval, 25f, 130f, false, p)
            }
        }
        c.restore()

        // Thinking particles
        if (state == State.THINKING) {
            p.style = Paint.Style.FILL; col(red)
            for (i in 0 until 6) {
                val ang = t / 450.0 + i * PI / 3
                c.drawCircle(cx + cos(ang).toFloat() * r * 1.3f, cy + sin(ang).toFloat() * r * 1.3f, r * 0.035f, p)
            }
        }

        // One pending frame at a time. Slow when idle/asleep to save battery.
        removeCallbacks(tick)
        val delay = when (state) { State.SLEEP -> 120L; State.IDLE -> 40L; else -> 16L }
        postDelayed(tick, delay)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }
}
